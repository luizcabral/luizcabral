v1 = int(input('Digite o primeiro valor: '))
v2 = int(input('Digite o segundo valor: '))
soma = v1 + v2
print("A soma é", soma)
